public interface Airfare {
    double calculateAmount();
}